import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';
import Location from './Location';

class LocationMonitoring extends Model {
    public isMonitored!: boolean;
    public hasAlerts!: boolean;
    public lastAlertDate?: Date;
    public lastInspectionDate?: Date;
    public nextInspectionDate?: Date;
    public inspectionNotes?: string;
    public monitoringMode: 'MANUAL' | 'AUTOMATED' | 'HYBRID';
    public lastUpdatedBy?: string;
}