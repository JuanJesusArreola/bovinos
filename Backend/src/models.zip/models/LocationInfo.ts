import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';
import Location from './Location';

class LocationInfo extends Model {
  public id!: string;
  public locationId!: string;
  public description: string;
  public address?: string;
  public city?: string;
  public state?: string;
  public country?: string;
  public postalCode: string;
  public timezone?: string;
  public notes: string;
  public tags: string;
  public images?: string[];
  public documents?: string[];
  public videos?: string[];
  public maps?: string[];
  public lastReviewedAt?: Date;
  public reviewedBy?: string;
}

LocationInfo.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  locationId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'locations', key: 'id' },
    onDelete: 'CASCADE'
  },
  address: { type: DataTypes.STRING(500), allowNull: true },
  city: { type: DataTypes.STRING(200), allowNull: true },
  state: { type: DataTypes.STRING(200), allowNull: true },
  country: { type: DataTypes.STRING(200), allowNull: true, defaultValue: 'Mexico' },
  capacity: { type: DataTypes.JSONB, allowNull: true },
  geofenceConfig: { type: DataTypes.JSONB, allowNull: true },
  contactInfo: { type: DataTypes.JSONB, allowNull: true }
}, {
  sequelize,
  tableName: 'location_infos',
  timestamps: true,
  paranoid: true
});

export default LocationInfo;
