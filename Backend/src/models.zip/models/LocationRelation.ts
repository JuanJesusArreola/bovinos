import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';
import Location from './Location';

class LocationRelation extends Model {
  public parentLocationId?: string;
  public relatedLocations?: string[];
  public relationType: 'CONTAINS' | 'ADJACENT' | 'CONNECTED';
}

LocationRelation.init({
  id: { type: DataTypes.UUID, primaryKey: true, defaultValue: DataTypes.UUIDV4 },
  locationId: { type: DataTypes.UUID, allowNull: false, references: { model: 'locations', key: 'id' }, onDelete: 'CASCADE' },
  farmId: { type: DataTypes.UUID, allowNull: true },
  ownerId: { type: DataTypes.UUID, allowNull: true },
  managerId: { type: DataTypes.UUID, allowNull: true },
  accessRules: { type: DataTypes.JSONB, allowNull: true }
}, {
  sequelize,
  tableName: 'location_relations',
  timestamps: true
});

export default LocationRelation;
