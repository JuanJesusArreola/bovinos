import { DataTypes, Model, Optional, Op } from 'sequelize';
import sequelize from '../config/database';
import Location from './Location';

class LocationAsset extends Model {
    public capacity?: LocationCapacity;
    public soilType?: string;
    public elevation?: number;
    public slope?: number;
    public vegetation?: string[];
    public waterSources?: Array<{
        type: 'WELL' | 'RIVER' | 'POND' | 'STREAM' | 'SPRING' | 'TANK';
        name: string;
        coordinates: Coordinates;
        capacity?: number;
        quality?: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR';
      }>;
    public pastureQuality?: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR';
    public services?: LocationServices;
    public weatherStationId?: string;
    public assetUpdatedAt?: Date
    public assetUpdatedBy?: string   
}
