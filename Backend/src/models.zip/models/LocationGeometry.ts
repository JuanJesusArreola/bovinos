import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';
import Location from './Location';
import { Geometry } from 'geojson';

class LocationGeometry extends Model {
    public coordinates!: Coordinates;
    public geom: Geometry;
    public geofenceConfig?: GeofenceConfig;
    public geometrySource: 'GPS' | 'MANUAL' | 'IMPORTED';
    public geometryAccuracy: number;

}