import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class LocationRelation extends Model {
  public id!: string;
  public locationId!: string;
  public farmId?: string;
  public ownerId?: string;
  public managerId?: string;
  public accessRules?: any; // JSONB
  public createdAt!: Date;
  public updatedAt!: Date;
}

LocationRelation.init({
  id: { type: DataTypes.UUID, primaryKey: true, defaultValue: DataTypes.UUIDV4 },
  locationId: { type: DataTypes.UUID, allowNull: false, references: { model: 'locations', key: 'id' }, onDelete: 'CASCADE' },
  farmId: { type: DataTypes.UUID, allowNull: true },
  ownerId: { type: DataTypes.UUID, allowNull: true },
  managerId: { type: DataTypes.UUID, allowNull: true },
  accessRules: { type: DataTypes.JSONB, allowNull: true }
}, {
  sequelize,
  tableName: 'location_relations',
  timestamps: true
});

export default LocationRelation;
